A Pen created at CodePen.io. You can find this one at http://codepen.io/vivinantony/pen/gbENBB.

 http://www.thelittletechie.com/2015/03/love-heart-animation-using-css3.html